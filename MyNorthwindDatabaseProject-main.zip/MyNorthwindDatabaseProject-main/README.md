# COMSC230Project

1. Uploaded products.csv to repository (11/1/2021)
2. The repository now contains an app-scripts folder and a data folder. The app-scripts folder contains app-scripts for our group 4 products table and for all the database tables. The data folder contains an SQL file of the Northwind database (11/25/2021)